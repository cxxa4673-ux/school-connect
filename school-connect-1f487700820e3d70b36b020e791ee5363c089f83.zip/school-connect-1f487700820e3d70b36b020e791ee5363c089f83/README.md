# School-Connect — SaaS Education Ecosystem

A high-performance education platform featuring an ExamGoal-style CBT examination engine, authentic PYQ explorer (2018–2025), NCERT reference hub, role-customized portals (Student, Parent, Teacher, and Institution Admin), and a proactive Gemini AI academic advisor.

---

## 🔒 Security & Secret Safety Architecture

This application adheres strictly to zero-leakage security practices:

### 1. Server-Side Secret Isolation
- **Gemini API Key (`GEMINI_API_KEY`)**: Consumed strictly in the server runtime (`server.ts`). It is **never** prefixed with `VITE_`, `REACT_APP_`, or `NEXT_PUBLIC_`, and is **never** sent to the client browser.
- **Client-Side Requests**: The frontend interacts solely with sanitized `/api/ai/*` backend proxy endpoints.
- **Zero Hardcoded Secrets**: No credentials, database URIs, API keys, or private tokens exist as literals anywhere in client or server code.

### 2. Error & Log Sanitization
- API error handlers catch and sanitize errors before returning responses. Stack traces, raw upstream messages, and sensitive context objects are stripped out.
- Server logs avoid printing authorization headers, tokens, or environment values.

### 3. Environment Variables & `.gitignore`
- `.env*` files are strictly excluded via `.gitignore`.
- Reference configuration is documented with non-sensitive placeholders in `.env.example`.

> ⚠️ **CRITICAL GIT HISTORY WARNING & ROTATION POLICY**:
> If any secret, API key, token, or database connection string was ever previously hardcoded or committed to this repository's git history, **that old value remains accessible in the git history logs**. You **MUST immediately rotate and invalidate** all previous API keys, database credentials, and service tokens in their respective provider consoles (Google Cloud / Google AI Studio / Stripe / Supabase / Firebase / AWS) before production deployment.

---

## 🛠️ Local Development & Deployment

### Setup
```bash
# Install dependencies
npm install

# Configure environment
cp .env.example .env
# Edit .env and supply your GEMINI_API_KEY

# Start development server
npm run dev
```

### Production Build
```bash
# Builds the Vite React SPA and bundles the Express server with esbuild
npm run build

# Start production server
npm start
```
